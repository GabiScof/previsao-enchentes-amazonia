from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import pandas as pd
import time

# Caminho do ChromeDriver (substitua pelo caminho correto, se necessário)
chrome_driver_path = "C:\\Users\\sique\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe" # Certifique-se de que o ChromeDriver está na mesma pasta do script

# Configuração do Selenium para usar Google Chrome
options = webdriver.ChromeOptions()
options.add_argument("--headless")  # Roda sem abrir a janela (remova se quiser ver o navegador)

# Inicializa o WebDriver
service = Service(chrome_driver_path)
driver = webdriver.Chrome(service=service, options=options)

# URL do site com a tabela
url = "https://portodemanaus.com.br/nivel-do-rio-negro/"
driver.get(url)
time.sleep(2)

# Lista de anos, semestres e meses
anos = [str(i) for i in range(2000, 2025)]
meses_1_semestre = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho"]
meses_2_semestre = ["Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

# Loop pelos anos, semestres e meses
for ano in anos:
    for semestre, meses in enumerate([meses_1_semestre, meses_2_semestre], start=1):
        for mes in meses:
            print(f"Coletando dados para {ano} - {mes}...")

            # Aguarda até que os selects estejam visíveis
            WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.TAG_NAME, "select")))

            selects = driver.find_elements(By.TAG_NAME, "select")
            
            if len(selects) < 3:
                print(f"⚠️ Selects não encontrados corretamente para {ano} - {mes}, pulando...")
                continue

            # Seleciona o ano
            select_ano = Select(selects[0])
            select_ano.select_by_visible_text(ano)
            time.sleep(1)

            # Seleciona o semestre
            select_semestre = Select(selects[1])
            select_semestre.select_by_visible_text(f"{semestre}º Semestre")
            time.sleep(1)

            # Seleciona o mês
            try:
                select_mes = Select(selects[2])
                select_mes.select_by_visible_text(mes)
                time.sleep(2)
            except:
                print(f"❌ Não tinha o mês de {mes} para o ano de {ano}")
                continue

            # Coleta os dados da tabela
            try:
                tabela = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "table")))
                cabecalho = tabela.find_elements(By.TAG_NAME, "th")
                linhas = tabela.find_elements(By.TAG_NAME, "tr")

                dados = []
                dados.append([coluna.text for coluna in cabecalho])

                for linha in linhas:
                    colunas = linha.find_elements(By.TAG_NAME, "td")
                    dados.append([float(coluna.text.replace(",", ".")) for coluna in colunas])

                # Salva os dados em CSV
                if dados:
                    df = pd.DataFrame(dados)
                    nome_arquivo = f"rioNegro_{ano}_{mes}.csv"
                    df.to_csv(nome_arquivo, index=False, encoding="utf-8")
                    print(f"✅ Arquivo {nome_arquivo} salvo!")

                    df = pd.read_csv(nome_arquivo)
    
                    if len(df) >= 3:
                        df = df.drop(index=1)
                    
                        df = df.reset_index(drop=True)
                                                
                        df.to_csv(nome_arquivo, index=False, encoding='utf-8')
                        print(f"Arquivo '{nome_arquivo}' atualizado com sucesso!")
            except Exception as e:
                print(f"❌ Erro ao coletar a tabela para {ano} - {mes}: {e}")

# Fecha o WebDriver
driver.quit()
